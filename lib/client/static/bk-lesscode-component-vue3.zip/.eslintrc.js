module.exports = {
  root: true,
  extends: ['@blueking/eslint-config-bk/vue3'],
};
