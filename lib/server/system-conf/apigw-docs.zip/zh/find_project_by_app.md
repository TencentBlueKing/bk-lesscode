### 资源描述
根据绑定的蓝鲸应用 appCode 和 moduleCode 获取相应lesscode应用的信息

### 请求参数说明
|   参数名称   |    参数类型  |  必须  |     参数说明     |
| ------------ | ------------ | ------ | ---------------- |
| bk_app_code | string | 是 | 应用ID(app id)，可以通过 蓝鲸开发者中心 -> 应用基本设置 -> 基本信息 -> 鉴权信息 获取 |
| bk_app_secret | string | 是 | 安全秘钥(app secret)，可以通过 蓝鲸开发者中心 -> 应用基本设置 -> 基本信息 -> 鉴权信息 获取 |
| appCode | string | 是 | lesscode应用绑定的蓝鲸应用Code |
| moduleCode | string | 是 | lesscode应用绑定的蓝鲸应用模块Code |


### 调用示例
```json
{
    appCode: 'demoproject',
    moduleCode: 'default'
}
```

### 返回结果
```json
{
  "code": 0,
  "message": "OK",
  "data": {
    "id": 1,
    "projectName": "proj1",
    "projectCode": "projCode1",
    "linkUrl": "/project/1/pages"
  }
}
```

### 返回结果说明
|   参数名称   |  参数类型  |           参数说明             |
| ------------ | ---------- | ------------------------------ |
|data.id|      number      |             应用id                   |
|data.projectName|      string      |             应用名称                   |
|data.projectCode|      string      |             应用Code                   |
|data.linkUrl|      string      |             应用访问入口                   |