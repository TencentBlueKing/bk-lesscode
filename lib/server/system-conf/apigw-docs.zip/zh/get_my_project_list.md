### 描述

获取有应用开发权限的应用列表

### 输入参数
| 参数名称     | 参数类型     | 必选   | 描述             |
| ------------ | ------------ | ------ | ---------------- |
| bk_app_code | string | 是 | 应用ID(app id)，可以通过 蓝鲸开发者中心 -> 应用基本设置 -> 基本信息 -> 鉴权信息 获取 |
| bk_app_secret | string | 是 | 安全秘钥(app secret)，可以通过 蓝鲸开发者中心 -> 应用基本设置 -> 基本信息 -> 鉴权信息 获取 |


### 调用示例
```json
{}
```

### 响应示例
```json
{
  "code": 0,
  "message": "OK",
  "data": [
      {
            "id": 1,
            "deleteFlag": 0,
            "projectCode": "demoproject",
            "projectName": "demo项目",
            "projectDesc": "这是一个demo项目",
            "status": 0,
            "appCode": "demoproject",
            "moduleCode": "default",
            "archiveFlag": 0,
            "isOffcial": 0,
            "isEnableDataSource": 0,
            "offcialType": null,
            "framework": "vue3"
        }
  ]
}
```

### 响应参数说明
| 参数名称     | 参数类型   | 描述                           |
| ------------ | ---------- | ------------------------------ |
|data| array |  有开发权限的应用列表 |