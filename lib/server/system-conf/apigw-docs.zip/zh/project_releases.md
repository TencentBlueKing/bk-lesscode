### 资源描述
获取用户有权限的项目列表及项目版本号列表

### 请求参数说明
|   参数名称   |    参数类型  |  必须  |     参数说明     |
| ------------ | ------------ | ------ | ---------------- |
| bk_app_code | string | 是 | 应用ID(app id)，可以通过 蓝鲸开发者中心 -> 应用基本设置 -> 基本信息 -> 鉴权信息 获取 |
| bk_app_secret | string | 是 | 安全秘钥(app secret)，可以通过 蓝鲸开发者中心 -> 应用基本设置 -> 基本信息 -> 鉴权信息 获取 |

### 调用示例
```json
{}
```

### 返回结果
```json
{
  "code": 0,
  "message": "OK",
  "data": [
    {
      "projectId": 1,
      "projectCode": "test",
      "projectName": "测试",
      "versionList": ["v1.0.0", "v1.0.1"]
    }
  ]
}
```

### 返回结果说明

`data`：用户有权限的项目及发布版本号列表

|   字段   |  类型  |           描述             |
| ------------ | ---------- | ------------------------------ |
|projectId| number |  项目ID |
|projectCode| string |  项目Code |
|projectName| string |  项目名称 |
|versionList| array | 版本号列表 |